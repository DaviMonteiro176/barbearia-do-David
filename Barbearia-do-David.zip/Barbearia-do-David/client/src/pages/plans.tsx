import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, DollarSign } from "lucide-react";

const planImages = [
  "https://images.unsplash.com/photo-1621605815971-fbc98d665033?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
  "https://images.unsplash.com/photo-1599351431202-1e0f0137899a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
  "https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
  "https://images.unsplash.com/photo-1586297135537-94bc9ba060aa?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
];

export default function PlansPage() {
  const { data: servicePlans } = useQuery({
    queryKey: ["/api/service-plans"],
  });

  return (
    <div className="space-y-6">
      <div className="mb-6">
        <h2 className="text-2xl font-semibold text-dark-brown mb-2">Nossos Planos</h2>
        <p className="text-warm-gray">Escolha o plano ideal para suas necessidades</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {servicePlans?.map((plan: any, index: number) => (
          <Card 
            key={plan.id} 
            className={`hover:shadow-md transition-shadow duration-200 ${
              plan.isPopular ? "border-2 border-saddle-brown relative" : ""
            }`}
          >
            {plan.isPopular && (
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-saddle-brown text-cream px-4 py-1 rounded-full text-sm font-medium">
                Mais Popular
              </div>
            )}
            
            <div className="aspect-video bg-gray-200">
              <img
                src={planImages[index % planImages.length]}
                alt={plan.name}
                className="w-full h-full object-cover rounded-t-lg"
              />
            </div>
            
            <CardHeader>
              <CardTitle className="text-xl font-semibold text-dark-brown">
                {plan.name}
              </CardTitle>
              <p className="text-warm-gray">{plan.description}</p>
            </CardHeader>
            
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-1">
                  <DollarSign className="w-5 h-5 text-saddle-brown" />
                  <span className="text-2xl font-bold text-saddle-brown">
                    R$ {parseFloat(plan.price).toFixed(0)}
                  </span>
                </div>
                <div className="flex items-center space-x-1 text-sm text-warm-gray">
                  <Clock className="w-4 h-4" />
                  <span>{plan.duration} minutos</span>
                </div>
              </div>
              
              <div className="space-y-2 mb-4">
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="w-full justify-start text-saddle-brown hover:text-dark-brown p-0"
                >
                  Ver Vantagens
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="w-full justify-start text-saddle-brown hover:text-dark-brown p-0"
                >
                  Termos de Uso
                </Button>
              </div>
              
              <Button className="w-full bg-saddle-brown hover:bg-saddle-brown/90 text-cream">
                Escolher Plano
              </Button>
            </CardContent>
          </Card>
        )) || (
          <div className="col-span-full text-center py-8">
            <p className="text-warm-gray">Carregando planos...</p>
          </div>
        )}
      </div>
    </div>
  );
}
