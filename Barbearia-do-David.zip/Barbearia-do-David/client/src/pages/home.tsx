import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Calendar, Scissors, Sparkles } from "lucide-react";
import AppointmentBooking from "@/components/appointment-booking";

export default function HomePage() {
  const [isBookingOpen, setIsBookingOpen] = useState(false);

  const { data: user } = useQuery({
    queryKey: ["/api/user/1"],
  });

  const { data: appointments } = useQuery({
    queryKey: ["/api/appointments/user/1"],
  });

  const upcomingAppointments = appointments?.filter(
    (apt: any) => apt.status === "confirmed" || apt.status === "pending"
  ) || [];

  return (
    <div className="space-y-6">
      {/* Plan Status Card */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold david-dark">Status do Plano</h2>
            <Badge className="bg-green-100 text-green-800">
              {user?.planStatus === "active" ? "Ativo" : "Inativo"}
            </Badge>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <p className="text-david-gray mb-2">Plano Atual</p>
              <p className="font-semibold text-lg">{user?.currentPlan || "Nenhum plano ativo"}</p>
              <p className="text-sm text-david-gray">
                {user?.planExpiry ? `Válido até ${new Date(user.planExpiry).toLocaleDateString('pt-BR')}` : ""}
              </p>
            </div>
            <div className="text-right">
              <Button className="hover:bg-david-gray text-david-cream bg-[#f8f5ed]">
                Renovar Plano
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>



      {/* Quick Actions */}
      <div className="grid md:grid-cols-2 gap-6">
        <Dialog open={isBookingOpen} onOpenChange={setIsBookingOpen}>
          <DialogTrigger asChild>
            <Card className="cursor-pointer hover:shadow-md transition-shadow duration-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold david-dark mb-2">Novo Agendamento</h3>
                    <p className="text-david-gray">Agende seu próximo corte</p>
                  </div>
                  <Calendar className="w-8 h-8 text-david-dark" />
                </div>
              </CardContent>
            </Card>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Novo Agendamento</DialogTitle>
            </DialogHeader>
            <AppointmentBooking 
              onClose={() => setIsBookingOpen(false)}
              onSuccess={() => {
                setIsBookingOpen(false);
                // Close sidebar on mobile after successful appointment booking
                if (window.innerWidth < 1024) {
                  // Access the sidebar state through the parent component
                  const event = new CustomEvent('closeSidebar');
                  window.dispatchEvent(event);
                }
              }}
            />
          </DialogContent>
        </Dialog>

        <Card 
          className="bg-cover bg-center relative"
          style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1585747860715-2ba37e788b70?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400')"
          }}
        >
          <div className="absolute inset-0 bg-david-dark/70 rounded-lg"></div>
          <CardContent className="p-6 relative z-10 text-david-cream">
            
          </CardContent>
        </Card>
      </div>

      {/* Upcoming Appointments */}
      <Card>
        <CardHeader>
          <CardTitle className="david-dark">Próximos Agendamentos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {upcomingAppointments.length > 0 ? (
              upcomingAppointments.map((appointment: any) => (
                <div key={appointment.id} className="flex items-center justify-between p-4 bg-david-cream rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="bg-david-dark text-david-cream p-3 rounded-full">
                      {appointment.serviceName.includes("Barba") ? <Sparkles className="w-5 h-5" /> : <Scissors className="w-5 h-5" />}
                    </div>
                    <div>
                      <p className="font-semibold">{appointment.serviceName}</p>
                      <p className="text-sm text-david-gray">
                        {new Date(appointment.date).toLocaleDateString('pt-BR')} - {appointment.time}
                      </p>
                      <p className="text-sm text-david-gray">Com {appointment.barberName}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge 
                      className={
                        appointment.status === "confirmed" 
                          ? "bg-green-100 text-green-800" 
                          : "bg-yellow-100 text-yellow-800"
                      }
                    >
                      {appointment.status === "confirmed" ? "Confirmado" : "Pendente"}
                    </Badge>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-david-gray text-center py-4">Nenhum agendamento próximo</p>
            )}
          </div>
          <div className="mt-4 text-center">
            <Button variant="ghost" className="text-david-dark hover:text-david-gray">
              Ver Todos os Agendamentos
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
