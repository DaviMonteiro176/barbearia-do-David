import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus } from "lucide-react";

export default function AppointmentsPage() {
  const { data: appointments } = useQuery({
    queryKey: ["/api/appointments/user/1"],
  });

  const activeAppointments = appointments?.filter(
    (apt: any) => apt.status === "confirmed" || apt.status === "pending"
  ) || [];

  const historicalAppointments = appointments?.filter(
    (apt: any) => apt.status === "completed" || apt.status === "cancelled"
  ) || [];

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      confirmed: { className: "bg-green-100 text-green-800", text: "Confirmado" },
      pending: { className: "bg-yellow-100 text-yellow-800", text: "Pendente" },
      completed: { className: "bg-gray-100 text-gray-800", text: "Concluído" },
      cancelled: { className: "bg-red-100 text-red-800", text: "Cancelado" },
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;
    return <Badge className={config.className}>{config.text}</Badge>;
  };

  const AppointmentCard = ({ appointment, showActions = true }: { appointment: any, showActions?: boolean }) => (
    <Card className="hover:shadow-sm transition-shadow duration-200">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <img
              src="https://images.unsplash.com/photo-1585747860715-2ba37e788b70?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80"
              alt="Serviço"
              className="w-12 h-12 rounded-lg object-cover"
            />
            <div>
              <h3 className="font-semibold text-dark-brown">{appointment.serviceName}</h3>
              <p className="text-warm-gray">
                {new Date(appointment.date).toLocaleDateString('pt-BR')} às {appointment.time}
              </p>
              <p className="text-sm text-warm-gray">Barbeiro: {appointment.barberName}</p>
            </div>
          </div>
          <div className="text-right">
            {getStatusBadge(appointment.status)}
            {showActions && (appointment.status === "confirmed" || appointment.status === "pending") && (
              <div className="flex space-x-2 mt-2">
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="text-saddle-brown hover:text-dark-brown"
                >
                  Reagendar
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="text-red-600 hover:text-red-800"
                >
                  Cancelar
                </Button>
              </div>
            )}
            {!showActions && appointment.status === "completed" && (
              <Button 
                variant="ghost" 
                size="sm"
                className="text-saddle-brown hover:text-dark-brown mt-2"
              >
                Reagendar Mesmo Serviço
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl font-semibold text-dark-brown">
              Seus Agendamentos
            </CardTitle>
            <Button className="bg-saddle-brown hover:bg-saddle-brown/90 text-cream">
              <Plus className="w-4 h-4 mr-2" />
              Novo Agendamento
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="ativos" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="ativos">Ativos</TabsTrigger>
              <TabsTrigger value="historico">Histórico</TabsTrigger>
            </TabsList>
            
            <TabsContent value="ativos" className="space-y-4">
              {activeAppointments.length > 0 ? (
                activeAppointments.map((appointment: any) => (
                  <AppointmentCard key={appointment.id} appointment={appointment} />
                ))
              ) : (
                <div className="text-center py-8">
                  <p className="text-warm-gray">Nenhum agendamento ativo encontrado</p>
                  <Button className="mt-4 bg-saddle-brown hover:bg-saddle-brown/90 text-cream">
                    <Plus className="w-4 h-4 mr-2" />
                    Criar Primeiro Agendamento
                  </Button>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="historico" className="space-y-4">
              {historicalAppointments.length > 0 ? (
                historicalAppointments.map((appointment: any) => (
                  <AppointmentCard 
                    key={appointment.id} 
                    appointment={appointment} 
                    showActions={false}
                  />
                ))
              ) : (
                <div className="text-center py-8">
                  <p className="text-warm-gray">Nenhum histórico de agendamentos encontrado</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
