import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Crown } from "lucide-react";

const categories = [
  { id: "tudo", label: "Tudo" },
  { id: "conveniencia", label: "Conveniência" },
  { id: "esportes", label: "Esportes" },
  { id: "gastronomia", label: "Gastronomia" },
  { id: "lazer", label: "Lazer" },
  { id: "limpeza", label: "Limpeza" },
  { id: "saude", label: "Saúde/Estética" },
  { id: "servicos", label: "Serviços" },
  { id: "vestuario", label: "Vestuário" },
];

const categoryColors = {
  gastronomia: "bg-orange-100 text-orange-800",
  esportes: "bg-blue-100 text-blue-800",
  saude: "bg-green-100 text-green-800",
  lazer: "bg-purple-100 text-purple-800",
  servicos: "bg-gray-100 text-gray-800",
  vestuario: "bg-pink-100 text-pink-800",
  conveniencia: "bg-yellow-100 text-yellow-800",
  limpeza: "bg-teal-100 text-teal-800",
};

export default function LoyaltyClubPage() {
  const [selectedCategory, setSelectedCategory] = useState("tudo");

  const { data: user } = useQuery({
    queryKey: ["/api/user/1"],
  });

  const { data: benefits } = useQuery({
    queryKey: [`/api/loyalty-benefits${selectedCategory !== "tudo" ? `?category=${selectedCategory}` : ""}`],
  });

  return (
    <div className="space-y-6">
      {/* Club Status */}
      <Card className="bg-gradient-to-r from-saddle-brown to-dark-brown text-cream">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-2xl font-semibold mb-2">Clube do David</h2>
              <p className="text-cream/90">Membro {user?.loyaltyLevel} since Janeiro 2023</p>
            </div>
            <Crown className="w-12 h-12 text-yellow-300" />
          </div>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="bg-cream/10 rounded-lg p-4">
              <p className="text-sm text-cream/75 mb-1">Pontos Totais</p>
              <p className="text-2xl font-bold">{user?.loyaltyPoints || 0}</p>
            </div>
            <div className="bg-cream/10 rounded-lg p-4">
              <p className="text-sm text-cream/75 mb-1">Próximo Nível</p>
              <div className="flex items-center space-x-2">
                <p className="font-semibold">Platina</p>
                <span className="text-sm">(750 pts restantes)</span>
              </div>
            </div>
            <div className="bg-cream/10 rounded-lg p-4">
              <p className="text-sm text-cream/75 mb-1">Cupons Disponíveis</p>
              <p className="text-2xl font-bold">{user?.availableCoupons || 0}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Benefits Categories */}
      <Card>
        <CardHeader>
          <CardTitle className="text-dark-brown">Categorias de Benefícios</CardTitle>
        </CardHeader>
        <CardContent>
          {/* Category Filters */}
          <div className="flex flex-wrap gap-2 mb-6">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category.id)}
                className={
                  selectedCategory === category.id
                    ? "bg-saddle-brown text-cream hover:bg-saddle-brown/90"
                    : "hover:bg-warm-gray hover:text-cream"
                }
              >
                {category.label}
              </Button>
            ))}
          </div>

          {/* Benefits Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {benefits?.map((benefit: any) => (
              <Card key={benefit.id} className="hover:shadow-md transition-shadow duration-200">
                <div className="aspect-video bg-gray-200 rounded-t-lg">
                  <img
                    src="https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200"
                    alt={benefit.title}
                    className="w-full h-full object-cover rounded-t-lg"
                  />
                </div>
                <CardContent className="p-4">
                  <h4 className="font-semibold text-dark-brown mb-2">{benefit.title}</h4>
                  <p className="text-sm text-warm-gray mb-3">
                    {benefit.validUntil && `Válido até ${new Date(benefit.validUntil).toLocaleDateString('pt-BR')}`}
                  </p>
                  <div className="flex justify-between items-center">
                    <Badge 
                      className={
                        categoryColors[benefit.category as keyof typeof categoryColors] || 
                        "bg-gray-100 text-gray-800"
                      }
                    >
                      {categories.find(cat => cat.id === benefit.category)?.label || benefit.category}
                    </Badge>
                    <Button 
                      size="sm"
                      className="text-saddle-brown hover:text-dark-brown"
                      variant="ghost"
                    >
                      Resgatar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )) || (
              <div className="col-span-full text-center py-8">
                <p className="text-warm-gray">Nenhum benefício encontrado para esta categoria</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* How to Redeem */}
      <Card>
        <CardHeader>
          <CardTitle className="text-dark-brown">Como Resgatar Cupons</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="text-center">
              <div className="bg-saddle-brown text-cream w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="font-bold">1</span>
              </div>
              <h4 className="font-semibold mb-2">Escolha o Cupom</h4>
              <p className="text-sm text-warm-gray">
                Navegue pelas categorias e encontre o benefício desejado
              </p>
            </div>
            <div className="text-center">
              <div className="bg-saddle-brown text-cream w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="font-bold">2</span>
              </div>
              <h4 className="font-semibold mb-2">Clique em Resgatar</h4>
              <p className="text-sm text-warm-gray">Use seus pontos para ativar o cupom</p>
            </div>
            <div className="text-center">
              <div className="bg-saddle-brown text-cream w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="font-bold">3</span>
              </div>
              <h4 className="font-semibold mb-2">Apresente o Código</h4>
              <p className="text-sm text-warm-gray">
                Mostre o código no estabelecimento parceiro
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
